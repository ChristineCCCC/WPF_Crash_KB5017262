﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace CrashWithVirtualizationPanel
{
    // STEPS TO MAKE THE APP CRASH
    // In the text box area tape aa  then backspace then aaaa etc 

    // The VirtualizationStackPanel of the ListView is filled with ~400 elements that matches the content of the text box.
    // This scenario is close to how we use the ListView + VirtualizationStackPanel in our real application
    // Modifications to the ObservableCollection is done through the usage of the dispatcher

    public class MainViewModel : INotifyPropertyChanged
    {
        private const int MaxAmountInPanel = 400;

        private static readonly List<string> ListContents = new List<string>
        {
            "aaa", "aa", "bb", "cca", "egrgdf", "sgjhfghjs", "sgdhhhss", "sdegfsdghdhhhh"
        };

        private string _textFilter;

        private ObservableCollection<string> _elements = new ObservableCollection<string>(ListContents);

        public string TextFilter
        {
            get { return _textFilter; }
            set
            {
                _textFilter = value;
                OnPropertyChanged();
                UpdateListViewContents();
            }
        }

        public ObservableCollection<string> Elements
        {
            get { return _elements; }
        }

        /// <summary>
        /// Emulates an asynchronous update to the ListView using VistualizationStackPanel
        /// Some list of elements in computed based on the filter in the Filter text box.
        /// A thread is created and then the elements are updated using the UI dispatcher
        /// </summary>
        private void UpdateListViewContents()
        {
            var filtered = new List<string>();
            int i = 0;
            var smallFilterList = ListContents.Where(x => x.Contains(TextFilter)).ToList();
            if (smallFilterList.Count != 0)
            {
                while (filtered.Count < MaxAmountInPanel)
                {
                    smallFilterList.ForEach(x => filtered.Add(x + " " + i));
                }
            }
            else
            {
                filtered = smallFilterList;
            }

            var dispatcher = Application.Current.MainWindow.Dispatcher;
            DispatchInUI(dispatcher, filtered);
        }

        /// <summary>
        /// Dispatch asynchronously as if the result is coming from some async call
        /// </summary>
        private void DispatchInUI(Dispatcher dispatcher, List<string> filtered)
        {
            new Thread(o =>
            {
                Action inUIThreadAction = () =>
                {
                    Elements.Clear();
                    filtered.ForEach(x => Elements.Add(x));
                };
                dispatcher.BeginInvoke(inUIThreadAction);
            }).Start();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}